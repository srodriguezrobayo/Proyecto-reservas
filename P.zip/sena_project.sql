create database sena_project;
use sena_project;

create table tipo_usuario
(
    idTipo_usuario integer not null,
    Nombre_t_usuario varchar(20) not null,
    primary key(idTipo_usuario)
);

create table empleados
(
    id_empleado integer not null,
    Nom_empleado varchar(20) not null,
    Correo_elec_admin varchar(20) not null,
    Contrasena_empleado varchar(20) not null,
    Telefono_empleado integer not null,
    Genero_idGenero integer not null,
    Tipo_usuario_idTipo_usuario integer not null,
    primary key(id_empleado),
    foreign key(Tipo_usuario_idTipo_usuario) references tipo_usuario(idTipo_usuario),
    foreign key(Genero_idGenero) references genero(idGenero)
);

create table genero
(
    idGenero integer not null,
    Nombre_genero varchar(20) not null,
    primary key(idGenero)
);

create table departamento
(
    idDepartamento integer not null,
    Nombre_departamento varchar(20) not null,
    primary key(idDepartamento)
);

create table ciudad
(
    id_Ciudad integer not null,
    Nombre_ciudad varchar(20) not null,
    Departamento_idDepartamento integer not null,
    primary key(id_Ciudad),
    foreign key(Departamento_idDepartamento) references departamento(idDepartamento)
);

create table empresa
(
    Nit_Empresa integer auto_increment not null,
    Nombre_empresa varchar(20) not null,
    Correoelectronico_empresa varchar(20) not null,
    Contrasena_empresa varchar(20) not null,
    Telefono_empresa integer  null,
    Ciudad_id_Ciudad integer null,
    primary key(Nit_Empresa),
    foreign key(Ciudad_id_Ciudad) references ciudad(id_Ciudad)
);

create table cliente
(
    id_Cliente integer auto_increment not null,
    Nombre1_cliente varchar(20) not null,
    Nombre2_cliente varchar(20)  null,
    Apellido1_cliente varchar(20)  null,
    Apellido2_cliente varchar(20)  null,
    Correoelectronico_cliente varchar(20) not null,
    Contrasena_cliente varchar(20) not null,
    Telefono_cliente integer  null,
    Genero_idGenero integer  null,
    Ciudad_id_Ciudad integer  null,
    primary key(id_Cliente),
    foreign key(Genero_idGenero) references genero(idGenero),
    foreign key(Ciudad_id_Ciudad) references ciudad(id_Ciudad)
);

create table lugar_reservacion
(
    idLugar_reservacion integer not null,
    Nom_lugreserv varchar(20) not null,
    Direccion_lugreserv varchar(20) not null,
    Ciudad_id_Ciudad integer not null,
    primary key(idLugar_reservacion),
    foreign key(Ciudad_id_Ciudad) references ciudad(id_Ciudad)
);

create table servicio
(
    idServicio integer not null,
    Nombre_servicio varchar(20) not null,
    primary key(idServicio)
);

create table reservacion
(
    Id_Reservacion integer not null,
    Servicio_idServicio integer not null,
    Fecha_reservacion date not null,
    Hora_reservacion time not null,
    Lugar_reservacion_idLugar_reservacion integer not null,
    Empresa_Nit_Empresa integer not null,
    Cliente_id_Cliente integer not null,
    Valor integer not null,
    Empleados_id_empleado integer not null
);