<?php
    include_once("conexion.php");

    if(!empty($_POST['Ocasion']) && !empty($_POST['fecha reservacion']) && !empty($_POST['hora reservacion']) && !empty($_POST['Lugar reserva'])){

        $ocasion= $_POST['Ocasion'];
        $fecha= $_POST['fecha reservacion'];
        $hora= $_POST['hora reservacion'];
        $lugar= $_POST['Lugar reserva'];

        $sql = "INSERT INTO reservacion(Servicio_idServicio;Fecha_reservacion,Hora_reservacion,Lugar_reservacion_idLugar_reservacion) VALUES(:Oca,:Fec,:Hor,:Lug)";
        $stmt = $conexion->prepare($sql);
        $stmt->bindparam(":Oca",$ocasion);
        $stmt->bindparam(":Fec",$fecha);
        $stmt->bindparam(":Hor",$hora);
        $stmt->bindparam(":Lug",$lugar);

        if($stmt->execute()){
            header("location: Agendar.html");

        }else print("error en la consulta");
    }else{
        print("debe completar todos los campos del formulario");
    }   
?>