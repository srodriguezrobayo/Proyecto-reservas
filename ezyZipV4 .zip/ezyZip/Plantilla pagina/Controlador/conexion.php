<?php

$host = "localhost";
$user = "root";
$password = "";
$nom_bd = "sena_project";

try {
    $conexion = new PDO("mysql:host=".$host.";dbname=".$nom_bd, $user, $password);
    $conexion->exec("SET CHARACTER SET utf8");
} catch(PDOException $e) {
    echo "Error en la conexión: " . $e->getMessage();
}

?>
