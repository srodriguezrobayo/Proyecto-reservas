<?php
$con=mysqli_connect('127.0.0.1','root','','sena_project');
if (!$con) {

    die("<center><p>La conexión a la base de datos ha fallado: </p></center>" . mysqli_connect_error());
};
if(isset($_POST['loginc'])){
    $CE=$_POST['Correo_electronico'];
    $clave=$_POST['Contraseña'];
    $consulta="SELECT * FROM cliente WHERE Correoelectronico_cliente='".$CE."'";
    $esta=mysqli_query($con,$consulta);
    if (mysqli_num_rows($esta)>0){
        header('location:../perfilcliente.html');
        exit();
    }
    else {
        echo "<p><center>La contraseña o el correo están mal digitados</center></p>";
    }
}
if(isset($_POST['logine'])){
    $CE=$_POST['Correo_electronico'];
    $clave=$_POST['Contraseña'];
    $consulta="SELECT * FROM empresa WHERE Correoelectronico_empresa='".$CE."' ";
    $esta=mysqli_query($con,$consulta);
    if (mysqli_num_rows($esta)>0){
        header('location:../ perfilempresa.html');
        exit();
    }
    else {
        echo "<p><center>La contraseña o el correo están mal digitados</center></p>";
    }
}
?>